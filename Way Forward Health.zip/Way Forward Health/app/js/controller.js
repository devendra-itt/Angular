var DemoApp = angular.module("DemoApp",[]);
DemoApp.controller("DemoController",["$scope", function($scope){
    $scope.value='';
    var inoperation = false;
    var val1= 0;
    var operator = '';
    $scope.setvalue = function(val){
        $scope.value += val;
    }
    $scope.operations = function(button){
        console.log(button);
        val1 = parseInt($scope.value);
        $scope.value = ''
        operator = button;
    }
    $
    $scope.result = function(){
        if(operator=='+')
            $scope.value=parseInt($scope.value) + val1; 
        else if(operator=='-')
            $scope.value=parseInt($scope.value) - val1;
        else if(operator=='*')
            $scope.value=parseInt($scope.value) * val1;
        else
            $scope.value=parseInt($scope.value) / val1;
    }
                                     
}])
