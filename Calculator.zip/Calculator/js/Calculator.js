 angular.module("Calculator", []).controller("CalculatorController",
	function CalculatorController($scope) {
        debugger;
		$scope.displayValue = 0;
		$scope.memory = null;
		$scope.result = 0;
		$scope.operation = null;
 
		$scope.saveInMemory = function() {
			if ($scope.memory == null) {
				$scope.memory = parseFloat($scope.displayValue);
			}
		};
		$scope.clear = function() {
			$scope.operation = null;
			$scope.memory = null;
			$scope.displayValue = 0;
			$scope.result = 0;
		};
		$scope.sum = function() {
			$scope.saveInMemory();
			$scope.operation = "+";
			$scope.displayValue = 0;
		};
		$scope.subtract = function() {
			$scope.saveInMemory();
			$scope.operation = "-";
			$scope.displayValue = 0;
		};
		$scope.multiply = function() {
			$scope.saveInMemory();
			$scope.operation = "*";
			$scope.displayValue = 0;
		};
		$scope.divide = function() {
			$scope.saveInMemory();
			$scope.operation = "/";
			$scope.displayValue = 0;
		};
        $scope.square = function() {
			$scope.saveInMemory();
			$scope.result= parseFloat($scope.memory) * parseFloat($scope.memory);
		};
     
        
		$scope.result = function() {
			if ($scope.operation == "+"){
				$scope.result = parseFloat($scope.memory) + parseFloat($scope.displayValue);
			}
			else if ($scope.operation == "-"){
				$scope.result = parseFloat($scope.memory) - parseFloat($scope.displayValue);
			}
			else if ($scope.operation == "*"){
				$scope.result = parseFloat($scope.memory) * parseFloat($scope.displayValue);
			}
			else if ($scope.operation == "/"){
				$scope.result = parseFloat($scope.memory) / parseFloat($scope.displayValue);
			}
 
			$scope.memory = $scope.result;
		};
	}
);