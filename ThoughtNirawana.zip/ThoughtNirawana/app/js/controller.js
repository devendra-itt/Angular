var DemoApp = angular.module("DemoApp",[]);
DemoApp.controller("DemoController",["$scope","$http", function($scope,$http){
    var selecteditems =[]
    $scope.refresh = function(){
        $http.get("../app/products/products.json")
            .then(function(response) {
            localStorage.clear();
            localStorage.setItem('itemList', JSON.stringify(response.data));
            localStorage.setItem('selectedList', JSON.stringify(selecteditems));
        
        });
    };
    $scope.itemlist = JSON.parse(localStorage.getItem('itemList'));
    $scope.selectedList = JSON.parse(localStorage.getItem('selectedList'));
    $scope.moveThere = function(item){
        $scope.selectedList.push(item);
        var index = $scope.itemlist.indexOf(item);
        $scope.itemlist.splice(index, 1);
        localStorage.setItem('itemList', JSON.stringify($scope.itemlist));
        localStorage.setItem('selectedList', JSON.stringify($scope.selectedList));
    }

}])
