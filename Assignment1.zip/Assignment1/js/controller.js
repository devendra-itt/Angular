var app = angular.module('MyApp', [])
    app.controller('MyController', function ($scope,$window) {
        /*$scope.count = $scope.employees.length;
        debugger;
        $scope.Save = function () {  
                    $scope.employees.push({ 'name': $scope.name, 'dob': $scope.dob, 'email':$scope.email,'gender':$scope.gender,'remarks':$scope.remarks,'type':$scope.type });  
                    $localStorage.setItem("employees", angular.toJson($scope.employees));  
                }; 
        
        employeeList = $scope.employees; 
        employeeList = angular.fromJson($localStorage.getItem("employees"));*/

        
        $scope.customersList = JSON.parse($window.localStorage.getItem("employees"));
        
        var customers=$scope.customersList || [];
        $scope.Save = function (customer) {
            debugger;
            /*$scope.id= $scope.count + 1;*/
            customers.push({'name': $scope.name, 'dob': $scope.dob, 'email':$scope.email,'gender':$scope.gender,'address':$scope.address,'type':$scope.type });
            $window.localStorage.setItem("employees", JSON.stringify(customers)); 
            $scope.name = '';
            $scope.dob = '';
            $scope.email = '';
            $scope.gender = 'female';
            $scope.address = '';
            $scope.type = '';
            
        }
        $scope.Delete = function(emp){
            debugger;
            var conf = confirm("Are you Sure You want to delete this entry");
            if(conf){
                customers.splice($scope.customersList.indexOf(emp), 1);
                $window.localStorage.setItem("employees", JSON.stringify(customers)); 
            }
                
        }
		var apiCall = function(){
			alert('calling');
			$.ajax({
            url: 'http://10.10.14.188:4800/api/v1/healthMonitor/DeviceStatus',
            headers: {
              'Jab_Device_id':'80f1374192a6d6eb9ebf48e2eba18366'  
            },
            method: 'GET',
            withCredentials: true,
            success: function(data){
              console.log('succes: '+data);
            }
          });
		}
        
    });